import 'package:leave_management/Models/Interfaces/calendar.dart';

class GregorianCalender extends Calendar {}

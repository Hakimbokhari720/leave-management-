abstract class Calendar {
  void calendarExpire() {}

  void calendarBegin() {}
}

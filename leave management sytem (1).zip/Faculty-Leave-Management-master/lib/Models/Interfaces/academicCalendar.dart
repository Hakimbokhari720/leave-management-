import 'package:leave_management/Models/Interfaces/calendar.dart';

class AcademicCalendar extends Calendar {}

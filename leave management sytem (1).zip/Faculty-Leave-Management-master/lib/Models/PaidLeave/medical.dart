import 'package:leave_management/Models/Interfaces/paid.dart';

class Medical extends Paid {}
